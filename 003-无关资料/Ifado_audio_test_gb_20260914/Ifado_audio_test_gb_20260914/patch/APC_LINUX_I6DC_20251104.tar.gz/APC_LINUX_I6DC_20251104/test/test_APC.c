
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#ifndef OS_WINDOWS
#include <sys/ioctl.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>

#include "AudioProcess.h"


#define USE_MALLOC          (1)
#define USE_JSON            (0)
#define FILTER_ENABLE       (0)
#define FREQ_AGC_ENABEL     (1)

unsigned int WorkingBuffer2[1] = {0};

typedef unsigned char                uint8;
typedef unsigned short               uint16;
typedef unsigned long                uint32;

float AVERAGE_RUN(int a)
{
    static unsigned int num = 0;
    static float avg = 0;
    if(num == 0) avg = 0;
    num++;
    avg = avg + ((float)a - avg) / ((float)num);  
    return avg;
}
unsigned int _OsCounterGetMs(void)
{
    struct  timeval t1;
    gettimeofday(&t1,NULL);
    unsigned int T = ( (1000000 * t1.tv_sec)+ t1.tv_usec )/1000;
    return T;
}

int main(int argc, char *argv[])
{
    short input[1024];
    unsigned int T0, T1;
    float avg = 0;
    float peak = 0;
    char input_file[512];
    char output_file[512];
    int counter=0;
    int intensity_band[6] = {3,24,40,64,80,128};
    int intensity[7] = {0,30,0,30,0,30,0};
    short eq_table[129]  = { 1, 1, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5, -5    };
    memset (eq_table,0,sizeof(short)*129);
    short compression_ratio_input[_AGC_CR_NUM] = {-65,-55,-48,-25,-18,-12,0};
    short compression_ratio_output[_AGC_CR_NUM] = {-65,-50,-27,-12,-1,-1,-1};
#if FREQ_AGC_ENABEL
    int freqBand[_AGC_FREQ_BAND_NUM] = {3000,6000,8000};
    int compressionRatioArrayLowInput[_AGC_CR_NUM] = {-80,-60,-40,-20,0,0,0};
    int compressionRatioArrayLowOutput[_AGC_CR_NUM] = {-5,-5,-5,-5,-5,-5,-5};
    int compressionRatioArrayMidInput[_AGC_CR_NUM] = {-80,-60,-40,-20,0,0,0};
    int compressionRatioArrayMidOutput[_AGC_CR_NUM] = {-80,-60,-40,-20,0,0,0};
    int compressionRatioArrayHighInput[_AGC_CR_NUM] = {-80,-60,-40,-20,0,0,0};
    int compressionRatioArrayHighOutput[_AGC_CR_NUM] = {-80,-60,-40,-20,0,0,0};
#endif

    AudioApcBufferConfig apc_switch;
    memset(&apc_switch,0,sizeof(AudioApcBufferConfig));
    apc_switch.anr_enable = 1;
    apc_switch.eq_enable = 1;
    apc_switch.dr_enable = 0;
    apc_switch.vad_enable = 0;
    apc_switch.agc_enable = 1;

    int buffersize = IaaApc_GetBufferSize(&apc_switch);
    if(buffersize == 0){
        printf("IaaApc_GetBufferSize() error.\t\n");
        return -1;
    }
    else{
        printf("IaaApc_GetBufferSize() succeed.\t\n");
    }
#if USE_MALLOC
    char *working_buf_ptr = (char*)malloc(buffersize);
#else
    char working_buf_ptr[512*1000];
#endif

#if USE_JSON
    unsigned int use_anr_intl_json = 1;
    char anr_intl_json_file[512];
    sprintf(anr_intl_json_file,"%s","./../sample/data/AnrInternalJson.json");
    int anr_intl_buffersize = IaaApc_GetJsonFileSize(anr_intl_json_file);
    if(anr_intl_buffersize == 0){
        printf("IaaApc_GetJsonFileSize() error. Can not load json file [%s]\t\n", anr_intl_json_file);
        use_anr_intl_json = 0;
    }
    else{
        printf("IaaApc_GetJsonFileSize() succeed.\t\n");
    }
#if USE_MALLOC
    char *anr_intl_json_buf_ptr = (char*)malloc(anr_intl_buffersize);
#else
    char anr_intl_json_buf_ptr[512*1000];
#endif
#endif

#if USE_JSON
    unsigned int use_apc_intl_json = 1;
    char apc_intl_json_file[512];
    sprintf(apc_intl_json_file,"%s","./../sample/data/ApcInternalJson.json");
    int apc_intl_buffersize = IaaApc_GetJsonFileSize(apc_intl_json_file);
    if(apc_intl_buffersize == 0){
        printf("IaaApc_GetJsonFileSize() error. Can not load json file [%s]\t\n", apc_intl_json_file);
        use_apc_intl_json = 0;
    }
    else{
        printf("IaaApc_GetJsonFileSize() succeed.\t\n");
    }
#if USE_MALLOC
    char *apc_intl_json_buf_ptr = (char*)malloc(apc_intl_buffersize);
#else
    char apc_intl_json_buf_ptr[512*1000];
#endif
#endif

    FILE * fin, * fout;
    int ret1;
    AudioProcessInit apc_init;
    AudioAnrConfig anr_config;
    AudioEqConfig eq_config;
    AudioHpfConfig hpf_config;
    AudioAgcConfig agc_config;
    APC_HANDLE handle;
    memset(&apc_init,0,sizeof(AudioProcessInit));
    memset(&anr_config,0,sizeof(AudioAnrConfig));
    memset(&eq_config,0,sizeof(AudioEqConfig));
    memset(&hpf_config,0,sizeof(AudioHpfConfig));
    memset(&agc_config,0,sizeof(AudioAgcConfig));
    int PN=128;
    apc_init.point_number = PN;
    apc_init.channel = 1;
    apc_init.sample_rate = IAA_APC_SAMPLE_RATE_16000;

    handle = IaaApc_Init((char *)working_buf_ptr, &apc_init, &apc_switch);
    if(handle==NULL){
        printf("IaaApc_Init() error.\t\n");
        return -1;
    }
    else{
        printf("IaaApc_Init() succeed.\t\n");
    }
    
    /******ANR Config*******/
    anr_config.anr_enable = apc_switch.anr_enable;
    anr_config.user_mode = 1;
    anr_config.anr_filter_mode = 0;
    memcpy(anr_config.anr_intensity_band, intensity_band, 6*sizeof(int));
    memcpy(anr_config.anr_intensity, intensity, 7*sizeof(int));
    anr_config.anr_smooth_level = 10;
    anr_config.anr_converge_speed = 2;
    /******EQ Config********/
    eq_config.eq_enable =apc_switch.eq_enable;
    eq_config.user_mode = 1;
    memcpy(eq_config.eq_gain_db, eq_table,_EQ_BAND_NUM*sizeof(short));
    /******HPF Config********/
    hpf_config.hpf_enable = apc_switch.eq_enable;
    hpf_config.user_mode =1;
    hpf_config.cutoff_frequency = AUDIO_HPF_FREQ_150;
    /******AGC Config********/
    agc_config.agc_enable = apc_switch.agc_enable;
    agc_config.user_mode = 1;
    agc_config.gain_info.gain_max  = 40;
    agc_config.gain_info.gain_min  = -10;
    agc_config.gain_info.gain_init = 12;
    agc_config.drop_gain_max = 36;
    agc_config.gain_step = 1;
    agc_config.attack_time = 1;
    agc_config.release_time = 1;
    agc_config.noise_gate_db = -80;
    memcpy(agc_config.compression_ratio_input, compression_ratio_input,_AGC_CR_NUM*sizeof(short));
    memcpy(agc_config.compression_ratio_output, compression_ratio_output,_AGC_CR_NUM*sizeof(short));
    agc_config.noise_gate_attenuation_db = 0;
    agc_config.drop_gain_threshold = -5;
    
    if(IaaApc_Config(handle,&anr_config,&eq_config,&hpf_config,NULL,NULL,&agc_config) != -0){
        printf("IaaApc_Config() error.\t\n");
        return -1;
    }
    else{
        printf("IaaApc_Config() succeed.\t\n");
    }
    
    // IaaApc_EnableComfortNoise(handle, 1, -50);

#if USE_JSON
    if(apc_switch.anr_enable && use_anr_intl_json){
        if(IaaApc_NrReadJson(handle, anr_intl_json_buf_ptr, anr_intl_json_file, anr_intl_buffersize) != 0){
            printf("IaaApc_NrReadJson() error.\t\n");
            return -1;
        }
        else{
            printf("IaaApc_NrReadJson() succeed.\t\n");
        }
    }
#endif

#if USE_JSON
    if(use_apc_intl_json){
        if(IaaApc_ReadJson(handle, apc_intl_json_buf_ptr, apc_intl_json_file, apc_intl_buffersize) != 0){
            printf("IaaApc_ReadJson() error.\t\n");
            return -1;
        }
        else{
            printf("IaaApc_ReadJson() succeed.\t\n");
        }
    }
#endif

#if FILTER_ENABLE
    float h[512];
    //filter 1
    AudioFilterConfig filter_design;
    filter_design.q_factor = 5;
    filter_design.f0 = 1000;
    filter_design.type = EQ_NOTCH_FILTER;
    filter_design.gain = -10;
    //filter 2
    AudioFilterConfig filter_design2;
    filter_design2.q_factor = 5;
    filter_design2.f0 = 5000;
    filter_design2.type = EQ_NOTCH_FILTER;
    filter_design2.gain = -10;
    //filter 3
    AudioFilterConfig filter_design3;
    filter_design3.q_factor = 5;
    filter_design3.f0 = 500;
    filter_design3.type = EQ_NOTCH_FILTER;
    filter_design3.gain = -10;

    if(IaaApc_FilterDesign(handle, 1, &filter_design) != 0){
        printf("IaaEq_FilterDesign() error.\t\n");
        return -1;
    }
    if(IaaApc_FilterDesign(handle, 2, &filter_design2) != 0){
        printf("IaaEq_FilterDesign() error.\t\n");
        return -1;
    }
    if(IaaApc_FilterDesign(handle, 3, &filter_design3) != 0){
        printf("IaaEq_FilterDesign() error.\t\n");
        return -1;
    }
    IaaApc_FilterFreqz(handle,h);
#endif
    
    
#if FREQ_AGC_ENABEL
    if(agc_config.user_mode == 2){
        IaaApc_SetAgcFreqBand(handle, freqBand);
        IaaApc_SetLowFreqCompressionRatioCurve(handle, compressionRatioArrayLowInput, compressionRatioArrayLowOutput);
        IaaApc_SetMidFreqCompressionRatioCurve(handle, compressionRatioArrayMidInput, compressionRatioArrayMidOutput);
        IaaApc_SetHighFreqCompressionRatioCurve(handle, compressionRatioArrayHighInput, compressionRatioArrayHighOutput);
    }
#endif

    AudioProcessInit apc_init_cpy;
    AudioAnrConfig anr_config_cpy;
    AudioEqConfig eq_config_cpy;
    AudioHpfConfig hpf_config_cpy;
    AudioAgcConfig agc_config_cpy;
    memset(&apc_init_cpy,0,sizeof(AudioProcessInit));
    memset(&anr_config_cpy,0,sizeof(AudioAnrConfig));
    memset(&eq_config_cpy,0,sizeof(AudioEqConfig));
    memset(&hpf_config_cpy,0,sizeof(AudioHpfConfig));
    memset(&agc_config_cpy,0,sizeof(AudioAgcConfig));
    if(IaaApc_GetConfig(handle, &apc_init_cpy, &anr_config_cpy, &eq_config_cpy, &hpf_config_cpy, NULL, NULL, &agc_config_cpy) != ALGO_APC_RET_SUCCESS){
        printf("IaaApc_GetConfig() error.\t\n");
        return -1;
    }
    else{
        printf("IaaApc_GetConfig() succeed.\t\n");
    }
    sprintf(input_file,"%s","./../sample/data/APC_AFE_16K.wav");
    sprintf(output_file,"%s","./../sample/data/APC_out_16K.wav");

    fin = fopen(input_file, "rb");
    if(!fin)
    {
        printf("the input file %s could not be open\n",input_file);
        return -1;
    }

    fout = fopen(output_file, "wb");
    if(!fout)
    {
        printf("the output file could not be open\n");
        return -1;
    }

    fread(input, sizeof(char), 44, fin); // read header 44 bytes
    fwrite(input, sizeof(char),44, fout); // write 44 bytes output

    while(fread(input, sizeof(short), apc_init.point_number*apc_init.channel, fin))
    {

        counter++;
        T0  = (long)_OsCounterGetMs();
        ret1 = IaaApc_Run(handle,input);
#if FILTER_ENABLE
        ret1 += IaaApc_FilterApply(handle, input);
#endif
        T1  = (long)_OsCounterGetMs();
        avg += (T1 - T0);
        if(peak < (T1 - T0))
            peak = (T1 - T0);
        
        if(counter%1000== 999)
        {
            printf("counter = %d\n", counter);
            printf("current time = %f\n", (float)counter*PN/apc_init.sample_rate);
            printf("process time = %lu(ms)\t",(long)(T1 - T0));
        }

        if(ret1 != 0)
        {
            printf("Error occured in APC\n");
            break;
        }

        fwrite(input, sizeof(short), apc_init.point_number*apc_init.channel, fout);
    }
    avg /= counter;
    printf("AVG is %.2f ms\n",avg);
    printf("PEAK is %.2f ms\n",peak);
    IaaApc_Free(handle);
    free(working_buf_ptr);
    fclose(fin);
    fclose(fout);

    printf("Done\n");
  return 0;
}
