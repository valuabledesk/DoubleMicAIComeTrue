
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#ifndef OS_WINDOWS
#include <sys/ioctl.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>

#include "AudioProcess.h"

#if (ANR_IPU_ENABLE)
#include "mi_sys.h"
#endif

#define USE_MALLOC               (1)
#define USE_JSON                 (1)
#define FILTER_ENABLE            (0)
#define FREQ_AGC_ENABEL          (0)
#define DIGITAL_GAIN_ENABLE      (0)

unsigned int WorkingBuffer2[1] = {0};

typedef unsigned char                uint8;
typedef unsigned short               uint16;
typedef unsigned long                uint32;

float AVERAGE_RUN(int a)
{
    static unsigned int num = 0;
    static float avg = 0;
    if(num == 0) avg = 0;
    num++;
    avg = avg + ((float)a - avg) / ((float)num);  
    return avg;
}
unsigned int _OsCounterGetMs(void)
{
    struct  timeval t1;
    gettimeofday(&t1,NULL);
    unsigned int T = ( (1000000 * t1.tv_sec)+ t1.tv_usec )/1000;
    return T;
}

int main(int argc, char *argv[])
{
#if (ANR_IPU_ENABLE)
    MI_SYS_Init(0);
#endif
    short input[1024];
    unsigned int T0, T1;
    float avg = 0;
    float peak = 0;
    char input_file[512];
    char output_file[512];
    int counter=0;
#if FREQ_AGC_ENABEL
    int freqBand[_AGC_FREQ_BAND_NUM];
    int compressionRatioArrayLowInput[_AGC_CR_NUM];
    int compressionRatioArrayLowOutput[_AGC_CR_NUM];
    int compressionRatioArrayMidInput[_AGC_CR_NUM];
    int compressionRatioArrayMidOutput[_AGC_CR_NUM];
    int compressionRatioArrayHighInput[_AGC_CR_NUM];
    int compressionRatioArrayHighOutput[_AGC_CR_NUM];
#endif
    
    AudioApcBufferConfig apc_switch;
    memset(&apc_switch,0,sizeof(AudioApcBufferConfig));
#if USE_JSON
    unsigned int use_apc_param_json = 1;
    char apc_para_json_file[512];
    sprintf(apc_para_json_file,"%s","./../sample/data/ApcParamJson.json");
    int apc_para_buffersize = IaaApc_GetJsonFileSize(apc_para_json_file);
    if(apc_para_buffersize == 0){
        printf("IaaApc_GetJsonFileSize() error. Can not load json file [%s]\t\n", apc_para_json_file);
        use_apc_param_json = 0;
    }
    else{
        printf("IaaApc_GetJsonFileSize() succeed.\t\n");
    }
#if USE_MALLOC
    char *apc_para_json_buf_ptr = (char*)malloc(apc_para_buffersize);
#else
    char apc_para_json_buf_ptr[512*1000];
#endif
    if(use_apc_param_json){
        if(IaaApc_SwitchReadFromJson(&apc_switch, apc_para_json_buf_ptr, apc_para_json_file, apc_para_buffersize) != 0){
            printf("IaaApc_SwitchReadFromJson() error.\t\n");
            return -1;
        }
        else{
            printf("IaaApc_SwitchReadFromJson() succeed.\t\n");
        }
    }
#endif

    int buffersize = IaaApc_GetBufferSize(&apc_switch);
    if(buffersize == 0){
        printf("IaaApc_GetBufferSize() error.\t\n");
        return -1;
    }
    else{
        printf("IaaApc_GetBufferSize() succeed.\t\n");
    }
#if USE_MALLOC
    char *working_buf_ptr = (char*)malloc(buffersize);
#else
    char working_buf_ptr[512*1000];
#endif

#if USE_JSON
    unsigned int use_anr_intl_json = 1;
    char anr_intl_json_file[512];
    sprintf(anr_intl_json_file,"%s","./../sample/data/AnrInternalJson.json");
    int anr_intl_buffersize = IaaApc_GetJsonFileSize(anr_intl_json_file);
    if(anr_intl_buffersize == 0){
        printf("IaaApc_GetJsonFileSize() error. Can not load json file [%s]\t\n", anr_intl_json_file);
        use_anr_intl_json = 0;
    }
    else{
        printf("IaaApc_GetJsonFileSize() succeed.\t\n");
    }
#if USE_MALLOC
    char *anr_intl_json_buf_ptr = (char*)malloc(anr_intl_buffersize);
#else
    char anr_intl_json_buf_ptr[512*1000];
#endif
#endif

#if USE_JSON
    unsigned int use_apc_intl_json = 1;
    char apc_intl_json_file[512];
    sprintf(apc_intl_json_file,"%s","./../sample/data/ApcInternalJson.json");
    int apc_intl_buffersize = IaaApc_GetJsonFileSize(apc_intl_json_file);
    if(apc_intl_buffersize == 0){
        printf("IaaApc_GetJsonFileSize() error. Can not load json file [%s]\t\n", apc_intl_json_file);
        use_apc_intl_json = 0;
    }
    else{
        printf("IaaApc_GetJsonFileSize() succeed.\t\n");
    }
#if USE_MALLOC
    char *apc_intl_json_buf_ptr = (char*)malloc(apc_intl_buffersize);
#else
    char apc_intl_json_buf_ptr[512*1000];
#endif
#endif

    FILE * fin, * fout;
    int ret1;
    AudioProcessInit apc_init;
    AudioAnrConfig anr_config;
    AudioEqConfig eq_config;
    AudioHpfConfig hpf_config;
    AudioAgcConfig agc_config;
    AudioApcOption apc_option;
    memset(&apc_init,0,sizeof(AudioProcessInit));
    memset(&anr_config,0,sizeof(AudioAnrConfig));
    memset(&eq_config,0,sizeof(AudioEqConfig));
    memset(&hpf_config,0,sizeof(AudioHpfConfig));
    memset(&agc_config,0,sizeof(AudioAgcConfig));
    memset(&apc_option,0,sizeof(AudioApcOption));
    APC_HANDLE handle;
    
#if USE_JSON
    if(use_apc_param_json){
        if(IaaApc_InitReadFromJson(&apc_init, apc_para_json_buf_ptr, apc_para_json_file, apc_para_buffersize) != 0){
            printf("IaaApc_InitReadFromJson() error.\t\n");
            return -1;
        }
        else{
            printf("IaaApc_InitReadFromJson() succeed.\t\n");
        }
    }
#endif
    handle = IaaApc_Init((char *)working_buf_ptr, &apc_init, &apc_switch);
    if(handle==NULL){
        printf("IaaApc_Init() error.\t\n");
        return -1;
    }
    else{
        printf("IaaApc_Init() succeed.\t\n");
    }

#if USE_JSON
    if(use_apc_param_json){
        if(IaaApc_ConfigReadFromJson(&anr_config, &eq_config, &hpf_config, &agc_config, apc_para_json_buf_ptr, apc_para_json_file, apc_para_buffersize) != 0){
            printf("IaaApc_ConfigReadFromJson() error.\t\n");
            return -1;
        }
        else{
            printf("IaaApc_ConfigReadFromJson() succeed.\t\n");
        }
    }
#endif
    if(IaaApc_Config(handle,&anr_config,&eq_config,&hpf_config,NULL,NULL,&agc_config) != -0){
        printf("IaaApc_Config() error.\t\n");
        return -1;
    }
    else{
        printf("IaaApc_Config() succeed.\t\n");
    }

#if USE_JSON
    if(apc_switch.anr_enable && use_anr_intl_json){
        if(IaaApc_NrReadJson(handle, anr_intl_json_buf_ptr, anr_intl_json_file, anr_intl_buffersize) != 0){
            printf("IaaApc_NrReadJson() error.\t\n");
            return -1;
        }
        else{
            printf("IaaApc_NrReadJson() succeed.\t\n");
        }
    }
#endif

#if USE_JSON
    if(use_apc_intl_json){
        if(IaaApc_ReadJson(handle, apc_intl_json_buf_ptr, apc_intl_json_file, apc_intl_buffersize) != 0){
            printf("IaaApc_ReadJson() error.\t\n");
            return -1;
        }
        else{
            printf("IaaApc_ReadJson() succeed.\t\n");
        }
    }
#endif

#if FILTER_ENABLE
    float h[512];
#if USE_JSON
    if(use_apc_param_json){
        if(IaaApc_FilterDesignReadFromJson(handle, apc_para_json_buf_ptr, apc_para_json_file, apc_para_buffersize) != 0){
            printf("IaaEq_FilterDesignReadFromJson() error.\t\n");
            return -1;
        }
        else{
            printf("IaaEq_FilterDesignReadFromJson() succeed.\t\n");
        }
    }
#endif
    IaaApc_FilterFreqz(handle,h);
#endif
    
    
#if FREQ_AGC_ENABEL
    if(agc_config.user_mode == 2){
#if USE_JSON
        if(use_apc_param_json){
            if(IaaApc_SetAgcReadFromJson(&freqBand[0], &compressionRatioArrayLowInput[0], &compressionRatioArrayLowOutput[0],
                        &compressionRatioArrayMidInput[0], &compressionRatioArrayMidOutput[0],
                        &compressionRatioArrayHighInput[0], &compressionRatioArrayHighOutput[0],
                        apc_para_json_buf_ptr, apc_para_json_file, apc_para_buffersize) != 0 ){
                printf("IaaAgc_SetAgcReadFromJson() error.\t\n");
                return -1;
            }
            else{
                printf("IaaAgc_SetAgcReadFromJson() succeed.\t\n");
            }
        }
#endif
        IaaApc_SetAgcFreqBand(handle, freqBand);
        IaaApc_SetLowFreqCompressionRatioCurve(handle, compressionRatioArrayLowInput, compressionRatioArrayLowOutput);
        IaaApc_SetMidFreqCompressionRatioCurve(handle, compressionRatioArrayMidInput, compressionRatioArrayMidOutput);
        IaaApc_SetHighFreqCompressionRatioCurve(handle, compressionRatioArrayHighInput, compressionRatioArrayHighOutput);
    }
#endif

#if DIGITAL_GAIN_ENABLE
#if USE_JSON
    if(use_apc_param_json){
        if(IaaApc_OptionReadFromJson(&apc_option, apc_para_json_buf_ptr, apc_para_json_file, apc_para_buffersize) != 0){
            printf("IaaApc_OptionReadFromJson() error.\t\n");
            return -1;
        }
        else{
            printf("IaaApc_OptionReadFromJson() succeed.\t\n");
        }
    }
#endif
#endif
    
    sprintf(input_file,"%s","./../sample/data/APC_AFE_16K.wav");
    sprintf(output_file,"%s","./../sample/data/APC_out_16K.wav");

    fin = fopen(input_file, "rb");
    if(!fin)
    {
        printf("the input file %s could not be open\n",input_file);
        return -1;
    }

    fout = fopen(output_file, "wb");
    if(!fout)
    {
        printf("the output file could not be open\n");
        return -1;
    }

    fread(input, sizeof(char), 44, fin); // read header 44 bytes
    fwrite(input, sizeof(char),44, fout); // write 44 bytes output

    while(fread(input, sizeof(short), apc_init.point_number*apc_init.channel, fin))
    {

        counter++;
        T0  = (long)_OsCounterGetMs();
#if DIGITAL_GAIN_ENABLE
        ret1 = IaaApc_ApplyDigitalGain(handle,input,apc_option.digital_gain[0]);
#endif
        ret1 = IaaApc_Run(handle,input);
#if FILTER_ENABLE
        ret1 += IaaApc_FilterApply(handle, input);
#endif

#if DIGITAL_GAIN_ENABLE
        ret1 += IaaApc_ApplyDigitalGain(handle,input,apc_option.digital_gain[1]);
#endif

        T1  = (long)_OsCounterGetMs();
        avg += (T1 - T0);
        if(peak < (T1 - T0))
            peak = (T1 - T0);
        
        if(counter%1000== 999)
        {
            printf("counter = %d\n", counter);
            printf("current time = %f\n", (float)counter*apc_init.point_number/apc_init.sample_rate);
            printf("process time = %lu(ms)\t",(long)(T1 - T0));
        }

        if(ret1 != 0)
        {
            printf("Error occured in APC\n");
            break;
        }

        fwrite(input, sizeof(short), apc_init.point_number*apc_init.channel, fout);
    }
    avg /= counter;
    printf("AVG is %.2f ms\n",avg);
    printf("PEAK is %.2f ms\n",peak);
    IaaApc_Free(handle);
    free(working_buf_ptr);
    fclose(fin);
    fclose(fout);
#if (ANR_IPU_ENABLE)
    MI_SYS_Exit(0);
#endif
    printf("Done\n");
  return 0;
}
