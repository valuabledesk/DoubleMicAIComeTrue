/* Sgs trade secret */
/* Copyright (c) [2019~2025] Sgs Technology Ltd.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
Sgs and be kept in strict confidence
(Sgs Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of Sgs Confidential
Information is unlawful and strictly prohibited. Sgs hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/
/*
 * File        : wave.c
 * Description : The simple implementation of RIFF/WAV access
 *               http://www-mmsp.ece.mcgill.ca/documents/AudioFormats/WAVE/Docs/riffmci.pdf
 */


#include "wave.h"

#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

#define RIFF_ID_RIFF        0x46464952 // "RIFF"
#define RIFF_ID_WAVE        0x45564157 // "WAVE"
#define RIFF_ID_FORMAT      0x20746D66 // "fmt"
#define RIFF_ID_DATA        0x61746164 // "data"

#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
#error "The current implementation does not cosider big endian case"
#endif

WAVE_HANDLE* Wave_Create(const char *file_name, WAVE_FORMAT wav_format, unsigned short num_channels, unsigned int sample_per_sec, unsigned short bits_per_sample)
{
    WAVE_HANDLE *handle;

    if (wav_format != WAVE_FORMAT_PCM)
    {
        printf( "Only PCM is supported\n");
        return NULL;
    }

    handle = (WAVE_HANDLE*)calloc(1, sizeof(WAVE_HANDLE));
    if (handle == NULL)
    {
        printf( "Can't allocate memory\n");
        return NULL;
    }

    // handle->file_handle = open(file_name, O_WRONLY | O_CREAT, 0666);
    handle->file_handle = creat(file_name, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    if (handle->file_handle < 0)
    {
        printf( "Can't create file %s\n", strerror(errno));
        goto ERROR_RETURN;
    }

    handle->is_output = true;

    handle->wave_header.chunk_id           = RIFF_ID_RIFF;
    handle->wave_header.chunk_size         = sizeof(handle->wave_header);
    handle->wave_header.wave_id            = RIFF_ID_WAVE;
    handle->wave_header.format_id          = RIFF_ID_FORMAT;
    handle->wave_header.format_size        = (unsigned int)(offsetof(WAVE_HEADER, data_id) - offsetof(WAVE_HEADER, wave_format));
    handle->wave_header.wave_format        = wav_format;
    handle->wave_header.num_channels       = num_channels;
    handle->wave_header.sample_per_sec     = sample_per_sec;
    handle->wave_header.byte_per_sec       = sample_per_sec * num_channels * bits_per_sample / 8;
    handle->wave_header.block_align        = num_channels * bits_per_sample / 8;
    handle->wave_header.bits_per_sample    = bits_per_sample;
    handle->wave_header.data_id            = RIFF_ID_DATA;
    handle->wave_header.data_size          = 0;

    if (write(handle->file_handle, &handle->wave_header, sizeof(handle->wave_header)) != sizeof(handle->wave_header))
    {
        printf( "Can't write file\n");
        goto ERROR_RETURN;
    }

    return handle;

 ERROR_RETURN:
    if (handle->file_handle > 0)
    {
        close(handle->file_handle);
    }

    free(handle);
    return NULL;
}

WAVE_HANDLE* Wave_Open(const char *file_name)
{
    WAVE_HANDLE *handle;

    handle = (WAVE_HANDLE*)calloc(1, sizeof(WAVE_HANDLE));
    if (handle == NULL)
    {
        printf( "Can't allocate memory\n");
        return NULL;
    }

    handle->file_handle = open(file_name, O_RDONLY);
    if (handle->file_handle < 0)
    {
        printf( "Can't open file %s\n", strerror(errno));
        goto ERROR_RETURN;
    }

    if (read(handle->file_handle, &handle->wave_header, sizeof(handle->wave_header)) != sizeof(handle->wave_header))
    {
        printf( "Can't read file\n");
        goto ERROR_RETURN;
    }

    handle->is_output = false;


    return handle;

ERROR_RETURN:
    if (handle->file_handle > 0)
    {
        close(handle->file_handle);
    }

    free(handle);
    return NULL;
}

WAVE_ERROR Wave_Close(WAVE_HANDLE *handle)
{
    WAVE_ERROR ret = WAVE_ERROR_NONE;

    if (handle->is_output)
    {
        // Update header again for size values
        lseek(handle->file_handle, 0, SEEK_SET);
        if (write(handle->file_handle, &handle->wave_header, sizeof(handle->wave_header)) != sizeof(handle->wave_header))
        {
            printf( "Can't write file\n");
            ret = WAVE_ERROR_WRITE_FAIL;
            goto RETURN;
        }
    }

RETURN:
    close(handle->file_handle);
    memset(handle, 0, sizeof(WAVE_HANDLE));

    return ret;
}

ssize_t Wave_Read(WAVE_HANDLE *handle, void *buffer, size_t sample_count)
{
    size_t byte_count = sample_count * Wave_GetBytePerSample(handle);

    if (handle->is_output)
    {
        printf( "The opened wave file is read only\n");
        return -1;
    }

    return read(handle->file_handle, buffer, byte_count) / Wave_GetBytePerSample(handle);
}

ssize_t Wave_Write(WAVE_HANDLE *handle, void *buffer, int sample_count)
{
    size_t byte_count = sample_count * Wave_GetBytePerSample(handle);
    ssize_t count_written;

    if (!handle->is_output)
    {
        printf( "The created wave file is write only\n");
        return -1;
    }

    count_written = write(handle->file_handle, buffer, byte_count);
    if (count_written != byte_count)
    {
        printf( "The write count is %d, but only %zd written\n", sample_count, count_written );
        return -1;
    }

    // update size info in wave headers
    handle->wave_header.chunk_size += byte_count;
    handle->wave_header.data_size += byte_count;

    return count_written / Wave_GetBytePerSample(handle);
}
