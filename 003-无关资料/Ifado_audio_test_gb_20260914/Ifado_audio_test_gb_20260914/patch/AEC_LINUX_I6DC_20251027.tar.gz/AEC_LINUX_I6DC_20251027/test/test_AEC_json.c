
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#ifndef OS_WINDOWS
#include <sys/ioctl.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>


#include "AudioAecProcess.h"


#define PN              (128)
#define USE_MALLOC      (1)
typedef unsigned char				uint8;
typedef unsigned short				uint16;
typedef unsigned long				uint32;


float AVERAGE_RUN(int a)
{
    static unsigned int num = 0;
    static float avg = 0;

        if(num == 0)
            avg = 0;

        num++;
        avg = avg + ((float)a - avg) / ((float)num);


    return avg;
}
unsigned int _OsCounterGetMs(void)
{
	struct  timeval t1;
	gettimeofday(&t1,NULL);
	unsigned int T = ( (1000000 * t1.tv_sec)+ t1.tv_usec ) / 1000;
	return T;
}

int main(int argc, char *argv[])
{
	short input[256];
	short input_aec[256];
#if USE_MALLOC
	char *WorkingBuffer2;
#else
	char WorkingBuffer2 [1024*500];
#endif

	char infileName[512];
	char infileName_aec[512];
	char outfileName[512];
	int counter=0;
	unsigned int T0, T1;
	float avg;
	FILE * fin, * fout, * fin_aec;


	char aec_para_json_file[512];
	sprintf(aec_para_json_file,"%s","./../sample/data/AecParamJson.json");
	unsigned int aec_para_buffersize = IaaAec_GetJsonFileSize(aec_para_json_file);


#if USE_MALLOC
	WorkingBuffer2 = (char*)malloc(IaaAec_GetBufferSize());
    char *aec_para_json_buf_ptr = (char*)malloc(aec_para_buffersize);
#endif

    ALGO_AEC_RET ret;
	AudioAecInit aec_init;
	AudioAecConfig aec_config;
	AEC_HANDLE handle;
    AudioAecOption aec_option;

    memset(&aec_init,0,sizeof(AudioAecInit));
	memset(&aec_config,0,sizeof(AudioAecConfig));
	memset(&aec_option,0,sizeof(AudioAecOption));
	ret = IaaAec_InitReadFromJson(&aec_init, aec_para_json_buf_ptr, aec_para_json_file, aec_para_buffersize);
	ret += IaaAec_ConfigReadFromJson(&aec_config, aec_para_json_buf_ptr, aec_para_json_file, aec_para_buffersize);
	ret += IaaAec_OptionReadFromJson(&aec_option, aec_para_json_buf_ptr, aec_para_json_file, aec_para_buffersize);


	handle = IaaAec_Init((char*)WorkingBuffer2, &aec_init);
	if (handle==NULL)
	{
		printf("AEC init error\r\n");
		return -1;
	}
	else
	{
		printf("AEC init succeed\r\n");
	}
	sprintf(infileName,"%s","./../sample/data/AEC_AFE_16K_mono.wav"); //near
	sprintf(infileName_aec,"%s","./../sample/data/I2S_16K_mono.wav"); //far
	sprintf(outfileName,"%s","./../sample/data/AecOut.wav");

	ret += IaaAec_Config(handle ,&(aec_config));
	ret += IaaAec_SetRecursiveRatio(handle, aec_option.recursive_ratio);
	ret += IaaAec_SetADFBlockNum(handle, aec_option.block_num);
	ret += IaaAec_SetMode(handle, aec_option.mode);
	if(ret != ALGO_AEC_RET_SUCCESS)
	{
		printf("Error occured in AEC config function \n");
		return -1;
	}

	fin = fopen(infileName, "rb");
	if(!fin)
	{		printf("the input file could not be open\n");
		return -1;
	}

	fout = fopen(outfileName, "wb");
	if(!fout)
	{
		printf("the output file could not be open\n");
		return -1;
	}

    fread(input, sizeof(char), 44, fin); // read header 44 bytes
	fwrite(input, sizeof(char),44, fout); // write 44 bytes output


	fin_aec = fopen(infileName_aec, "rb");
	if(!fin_aec)
	{
		printf("the input file could not be open\n");
		return -1;
	}
	fread(input_aec, sizeof(char), 44, fin_aec); // read header 44 bytes
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
	printf("The chip is big-endian!!!\n");
	int k=0;
	short right = 0x0000;
	short left = 0x0000;
#endif

	while(fread(input, sizeof(short), PN*aec_init.nearend_channel, fin))
	{
		fread(input_aec, sizeof(short), PN*aec_init.farend_channel, fin_aec);
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__


		for(k=0;k<PN*aec_init.nearend_channel;k++)
		{
			right = (input[k]>>8)&(0x00ff);
			left = (input[k]<<8)&(0xff00);
			input[k] = left|right;
			right = (input_aec[k]>>8)&(0x00ff);
			left = (input_aec[k]<<8)&(0xff00);
			input_aec[k] = left|right;
		}

#endif
		counter++;

		T0  = (long)_OsCounterGetMs();
		ret = IaaAec_Run(handle, input , input_aec );
		T1  = (long)_OsCounterGetMs();
		avg = AVERAGE_RUN(T1 - T0);

		if(counter%100 == 0)
		{
			printf("counter = %d\n", counter);
			printf("current time = %f\n", (float)counter*PN/aec_init.sample_rate);

			printf("process time = %lu(ms)\t",(long)(T1 - T0));
			printf("AVG is %.2f ms\n",avg);
		}
		if(ret != ALGO_AEC_RET_SUCCESS)
		{
			printf("Error occured in AEC run function \n");
			break;
		}

#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__


		for(k=0;k<PN*aec_init.nearend_channel;k++)
		{
			right = (input[k]>>8)&(0x00ff);
			left = (input[k]<<8)&(0xff00);
			input[k] = left|right;
		}

#endif
		fwrite(input, sizeof(short), PN*aec_init.nearend_channel, fout);

	}
	ret = IaaAec_Free(handle);
	if(ret != ALGO_AEC_RET_SUCCESS)
	{
		printf("Error occured in AEC free function \n");
		return -1;
	}
	fclose(fin);
	fclose(fin_aec);
	fclose(fout);

	printf("Done\n");
  return 0;
}
