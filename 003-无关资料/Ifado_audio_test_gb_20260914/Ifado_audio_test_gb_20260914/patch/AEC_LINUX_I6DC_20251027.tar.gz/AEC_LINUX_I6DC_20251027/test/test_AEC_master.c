
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#ifndef OS_WINDOWS
#include <sys/ioctl.h>
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>


#include "AudioAecProcess.h"


#define USE_MALLOC   (1)
typedef unsigned char				uint8;
typedef unsigned short				uint16;
typedef unsigned long				uint32;


float AVERAGE_RUN(int a)
{
    static unsigned int num = 0;
    static float avg = 0;

        if(num == 0)
            avg = 0;

        num++;
        avg = avg + ((float)a - avg) / ((float)num);


    return avg;
}
unsigned int _OsCounterGetMs(void)
{
	struct  timeval t1;
	gettimeofday(&t1,NULL);
	unsigned int T = ( (1000000 * t1.tv_sec)+ t1.tv_usec ) / 1000;
	return T;
}

int main(int argc, char *argv[])
{
	short input[1024];
	short input_aec[1024];
#if USE_MALLOC
	char *WorkingBuffer2;
#else
	char WorkingBuffer2 [1024*500];
#endif

	char infileName[512];
	char infileName_aec[512];
	char outfileName[512];
	int counter=0;
	unsigned int T0, T1;
	float avg;
	FILE * fin, * fout, * fin_aec;
    ALGO_AEC_RET ret;
	AudioAecInit aec_init;
	AudioAecConfig aec_config;
	AEC_HANDLE handle;
	
	unsigned int supMode_band[6] = {20,40,60,80,100,120};
	unsigned int supMode[7] = {4,4,4,4,4,4,4};
	
	int PN = 128;
	unsigned int recursive_ratio = 1;
	unsigned int block_num = 8;
	unsigned int mode = 0;
	aec_init.point_number = PN;
	aec_init.nearend_channel = 1;
	aec_init.farend_channel = 1;
	aec_config.delay_sample = 0;
	aec_init.sample_rate = IAA_AEC_SAMPLE_RATE_16000;
	aec_config.comfort_noise_enable = IAA_AEC_FALSE;
	memcpy(&(aec_config.suppression_mode_freq[0]),supMode_band,sizeof(int)*6);
	memcpy(&(aec_config.suppression_mode_intensity[0]),supMode,sizeof(int)*7);

#if USE_MALLOC
	WorkingBuffer2 = (char*)malloc(IaaAec_GetBufferSize());
#endif
	handle = IaaAec_Init((char*)WorkingBuffer2, &aec_init);
	if (handle==NULL)
	{
		printf("AEC init error\r\n");
		return -1;
	}
	else
	{
		printf("AEC init succeed\r\n");
	}
	sprintf(infileName,"%s",".//..//sample//data//AEC_AFE_16K_mono.wav"); //near
	sprintf(infileName_aec,"%s",".//..//sample//data//I2S_16K_mono.wav"); //far
	sprintf(outfileName,"%s",".//AecOut.wav");
	
	ret = IaaAec_Config(handle ,&(aec_config));
	ret += IaaAec_SetRecursiveRatio(handle, recursive_ratio);
	ret += IaaAec_SetADFBlockNum(handle, block_num);
	ret += IaaAec_SetMode(handle, mode);
	if(ret != ALGO_AEC_RET_SUCCESS)
	{
		printf("Error occured in AEC config function \n");
		return -1;
	}
	
	fin = fopen(infileName, "rb");
	if(!fin)
	{		printf("the input file could not be open\n");
		return -1;
	}

	fout = fopen(outfileName, "wb");
	if(!fout)
	{
		printf("the output file could not be open\n");
		return -1;
	}

    fread(input, sizeof(char), 44, fin); // read header 44 bytes
	fwrite(input, sizeof(char),44, fout); // write 44 bytes output


	fin_aec = fopen(infileName_aec, "rb");
	if(!fin_aec)
	{
		printf("the input file could not be open\n");
		return -1;
	}
	fread(input_aec, sizeof(char), 44, fin_aec); // read header 44 bytes
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
	printf("The chip is big-endian!!!\n");
	int k=0;
	short right = 0x0000;
	short left = 0x0000;
#endif

	while(fread(input, sizeof(short), PN*aec_init.nearend_channel, fin))
	{
		fread(input_aec, sizeof(short), PN*aec_init.farend_channel, fin_aec);
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__


		for(k=0;k<PN*aec_init.nearend_channel;k++)
		{
			right = (input[k]>>8)&(0x00ff);
			left = (input[k]<<8)&(0xff00);
			input[k] = left|right;
			right = (input_aec[k]>>8)&(0x00ff);
			left = (input_aec[k]<<8)&(0xff00);
			input_aec[k] = left|right;
		}

#endif
		counter++;

		T0  = (long)_OsCounterGetMs();
		ret = IaaAec_Run(handle, input , input_aec );
		T1  = (long)_OsCounterGetMs();
		avg = AVERAGE_RUN(T1 - T0);

		if(counter%100 == 0)
		{
			printf("counter = %d\n", counter);
			printf("current time = %f\n", (float)counter*PN/aec_init.sample_rate);

			printf("process time = %lu(ms)\t",(long)(T1 - T0));
			printf("AVG is %.2f ms\n",avg);
		}
		if(ret != ALGO_AEC_RET_SUCCESS)
		{
			printf("Error occured in AEC run function \n");
			break;
		}
		
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__


		for(k=0;k<PN*aec_init.nearend_channel;k++)
		{
			right = (input[k]>>8)&(0x00ff);
			left = (input[k]<<8)&(0xff00);
			input[k] = left|right;
		}

#endif
		fwrite(input, sizeof(short), PN*aec_init.nearend_channel, fout);

	}
	ret = IaaAec_Free(handle);
	if(ret != ALGO_AEC_RET_SUCCESS)
	{
		printf("Error occured in AEC free function \n");
		return -1;
	}
	fclose(fin);
	fclose(fin_aec);
	fclose(fout);

	printf("Done\n");
  return 0;
}
