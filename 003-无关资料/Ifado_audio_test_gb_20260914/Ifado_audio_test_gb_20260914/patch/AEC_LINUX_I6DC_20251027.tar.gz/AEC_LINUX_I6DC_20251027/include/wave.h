/* Sgs trade secret */
/* Copyright (c) [2019~2025] Sgs Technology Ltd.
All rights reserved.

Unless otherwise stipulated in writing, any and all information contained
herein regardless in any format shall remain the sole proprietary of
Sgs and be kept in strict confidence
(Sgs Confidential Information) by the recipient.
Any unauthorized act including without limitation unauthorized disclosure,
copying, use, reproduction, sale, distribution, modification, disassembling,
reverse engineering and compiling of the contents of Sgs Confidential
Information is unlawful and strictly prohibited. Sgs hereby reserves the
rights to any and all damages, losses, costs and expenses resulting therefrom.
*/
/*
 * File        : wave.h
 * Description : The simple implementation of RIFF/WAV access
 *               http://www-mmsp.ece.mcgill.ca/documents/AudioFormats/WAVE/Docs/riffmci.pdf
 */

#ifndef _WAVE_H_
#define _WAVE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdbool.h>

typedef enum {
    WAVE_ERROR_NONE             = 0,
    WAVE_ERROR_READ_FAIL        = 1,
    WAVE_ERROR_READ_ONLY        = 2,
    WAVE_ERROR_READ_EOF         = 3,
    WAVE_ERROR_WRITE_FAIL       = 4,
    WAVE_ERROR_WRITE_ONLY       = 5,
    WAVE_ERROR_UNSUPPORT_FORMAT = 6
} WAVE_ERROR;

typedef enum {
  WAVE_FORMAT_PCM = 0x0001,
} WAVE_FORMAT;

typedef struct {
    unsigned int   chunk_id;
    unsigned int   chunk_size;
    unsigned int   wave_id;
    unsigned int   format_id;
    unsigned int   format_size;
    unsigned short wave_format;
    unsigned short num_channels;
    unsigned int   sample_per_sec;
    unsigned int   byte_per_sec;
    unsigned short block_align;
    unsigned short bits_per_sample;
    unsigned int   data_id;
    unsigned int   data_size;
} WAVE_HEADER;

typedef struct {
    int         file_handle;
    WAVE_HEADER wave_header;
    bool        is_output;
} WAVE_HANDLE;

WAVE_HANDLE* Wave_Create(const char *file_name, WAVE_FORMAT wav_format, unsigned short num_channels, unsigned int sample_per_sec, unsigned short bits_per_sample);
WAVE_HANDLE* Wave_Open(const char *file_name);
WAVE_ERROR Wave_Close(WAVE_HANDLE *handle);
ssize_t Wave_Read(WAVE_HANDLE *handle, void *buffer, size_t count);
ssize_t Wave_Write(WAVE_HANDLE *handle, void *buffer, int count);
static inline size_t Wave_GetBytePerSample(WAVE_HANDLE *handle) { return (handle->wave_header.bits_per_sample+7)/8; }
static inline size_t Wave_GetSampleCount(WAVE_HANDLE *handle) { return handle->wave_header.data_size/handle->wave_header.block_align; }

#ifdef __cplusplus
}
#endif

#endif //_WAVE_H_
